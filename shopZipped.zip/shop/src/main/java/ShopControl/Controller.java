package ShopControl;

	import jakarta.annotation.Resource;
	import jakarta.servlet.ServletException;
	import jakarta.servlet.annotation.WebServlet;
	import jakarta.servlet.http.HttpServlet;
	import jakarta.servlet.http.HttpServletRequest;
	import jakarta.servlet.http.HttpServletResponse;
	import java.io.IOException;
	import java.io.PrintWriter;
	import java.sql.Connection;
	import java.sql.PreparedStatement;
	import java.sql.ResultSet;
	import java.sql.SQLException;
	import java.sql.Statement;
	import javax.sql.DataSource;
	import java.sql.DriverManager; 

import com.mysql.cj.jdbc.result.ResultSetMetaData;

	@WebServlet("/Controller")
	public class Controller extends HttpServlet {		
	    private static final long serialVersionUID = 1L;
	    @Resource(name="jdbc/project")
	    private DataSource datasource;
	 
	    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {	    	
//	    	PrintWriter out=response.getWriter();
//            Connection c=null;
//            Statement st=null;
//            ResultSet rs=null;
//            try {
//                c=datasource.getConnection();
//                String prod_name=request.getParameter("items");
//                System.out.println(prod_name+"hjkjsa");
//                String date=request.getParameter("date");
//                System.out.println(date+"hello");
//                
//              
////                PreparedStatement ps=c.prepareStatement("select *from profitTable");
////               
////               out.print("<table width=55% border=1>");
////            	 out.print("<caption><h1>Selling and Profit Details</h1></caption>");
////            	 rs=ps.executeQuery();
////            	ResultSetMetaData rsm=(ResultSetMetaData)rs.getMetaData();
////            	int tc=rsm.getColumnCount();
////            	for(int i=1; i<=tc; i++) {
////            	out.print("<th>"+rsm.getColumnName(i)+"</th>");
////            	}
////                
////                while(rs.next()) {
////                	
////                	out.print("<tr><td>"+rs.getString(1)+"</td><td>"+rs.getString(2)+"</td><td>"+rs.getString(3)+"</td><td>"+rs.getString(4)+"</td><td>"+rs.getString(5)+"</td></tr>");
////                	              	
////                }
////                
////                out.print("</table>");
////                out.print("<br>");
//                int buy_price=0;
//                int sale_price=0;
//                String query2="select *from profitTable where prod_name='"+prod_name+"' and date='"+date+"'";
//                st=c.createStatement();
//                rs=st.executeQuery(query2);
//                 while(rs.next()) {
//                	 buy_price+=Integer.parseInt(rs.getString(2))*Integer.parseInt(rs.getString(4));
//                     sale_price+=Integer.parseInt(rs.getString(3));
//                	              	
//                }
//                
//                int profit=sale_price-buy_price;
//                out.println("<b>Profit</b>");
//                out.println(profit);
//                
//                
//                
//                
//                
////                buy_price+=Integer.parseInt(rs.getString(2));
////            	sale_price+=Integer.parseInt(rs.getString(3));
//                
//            	
//            	
//            }
//            catch(SQLException e) {
//            	e.printStackTrace();
//            }
	    }
	        protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	        	response.setContentType("text/html");
	        	PrintWriter out=response.getWriter();
	            Connection c=null;
	            Statement st=null;
	            ResultSet rs=null;
	            try {
	               c=datasource.getConnection();
	                Class.forName("com.mysql.jdbc.Driver");
	                Connection c1=DriverManager.getConnection("jdbc:mysql://localhost:3306/shop","root","Captain@2004");
	                String prod_name=request.getParameter("items");
	                System.out.println(prod_name+"hjkjsa");
	                String date=request.getParameter("date");
	                System.out.println(date+"hello");
	                
	              
	                PreparedStatement ps=c1.prepareStatement("select *from profitTable where prod_name='"+prod_name+"' and date='"+date+"'");
	               
	                out.print("<table width=55% border=1>");
	            	out.print("<caption><h1>Selling and Profit Details</h1></caption>");
	            	rs=ps.executeQuery();
	            	ResultSetMetaData rsm=(ResultSetMetaData)rs.getMetaData();
	            	int tc=rsm.getColumnCount();
	            	for(int i=1; i<=tc; i++) {
	            	out.print("<th>"+rsm.getColumnName(i)+"</th>");
	            	}
	                
	                while(rs.next()) {
	                	
	                	out.print("<tr><td>"+rs.getString(1)+"</td><td>"+rs.getString(2)+"</td><td>"+rs.getString(3)+"</td><td>"+rs.getString(4)+"</td><td>"+rs.getString(5)+"</td></tr>");
	                	              	
	                }
	                
	                out.print("</table>");
	                out.print("<br>");
	                
	                int buy_price=0;
	                int sale_price=0;
	                String query2="select *from profitTable where prod_name='"+prod_name+"' and date='"+date+"'";
	                st=c.createStatement();
	                rs=st.executeQuery(query2);
	                 while(rs.next()) {
	                	 buy_price+=Integer.parseInt(rs.getString(2))*Integer.parseInt(rs.getString(4));
	                     sale_price+=Integer.parseInt(rs.getString(3));
	                	              	
	                }
	                
	                int profit=sale_price-buy_price;
	                out.println("<b>Profit</b>");
	                out.println(profit);                 
	        	
	        }
	            catch(Exception e) {
	            	e.printStackTrace();
	            }
	       
	
}
}